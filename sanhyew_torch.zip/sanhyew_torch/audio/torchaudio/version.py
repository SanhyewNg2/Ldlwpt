__version__ = '0.8.1'
git_version = 'e4e171a51714b2b2bd79e1aea199c3f658eddf9a'
